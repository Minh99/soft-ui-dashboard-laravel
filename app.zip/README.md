# Test
- không sửa cột `is_completed`, cột này để cho logic code tự update

- muốn pass day1:
    `is_passed_quiz_story_1 = 1,
    is_passed_quiz_story_2 = 1,
    is_passed_test_2 = 1,
    created_at = ngày quá khứ`

- muốn pass day2, day3, day5:
    `is_passed_quiz_story_1 = 1,
    is_passed_quiz_story_2 = 1,
    is_passed_quiz_story_3 = 1,
    is_passed_quiz_story_4 = 1,
    is_passed_test_2 = 1,
    created_at = ngày quá khứ`


- muốn pass day4:
    `is_passed_first_quiz = 1,
    is_passed_test_2 = 1,
    created_at = ngày quá khứ`

- muốn pass day6:
    `is_passed_first_quiz = 1`
