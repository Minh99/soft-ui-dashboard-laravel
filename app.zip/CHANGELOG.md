# Change Log
All notable changes to `Soft UI Dashboard Laravel` will be documented in this file.

## [1.0.0]
### Original Release
- Soft UI Dashboard Free
- Login
- Register
- Forgot password
- Profile edit
