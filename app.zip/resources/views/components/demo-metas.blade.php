<meta name="keywords" content="Learn with chat bot, English chat bot, English and Korea" />
<meta name="description" content="Learn with chat bot, English chat bot, English and Korea" />
<meta itemprop="name" content="Learn with chat bot, English chat bot, English and Korea" />
<meta itemprop="description" content="Learn with chat bot, English chat bot, English and Korea" />
<meta itemprop="image" content="https://s3.amazonaws.com/creativetim_bucket/products/602/original/soft-ui-dashboard-laravel.jpg" />
<meta name="twitter:card" content="product" />
<meta name="twitter:site" content="@creativetim" />
<meta name="twitter:title" content="Soft UI Dashboard Laravel by Creative Tim & UPDIVISION" />
<meta name="twitter:description" content="Learn with chat bot, English chat bot, English and Korea" />
<meta name="twitter:creator" content="@creativetim" />
<meta name="twitter:image" content="https://s3.amazonaws.com/creativetim_bucket/products/602/original/soft-ui-dashboard-laravel.jpg" />
<meta property="fb:app_id" content="655968634437471" />
<meta property="og:title" content="Soft UI Dashboard Laravel by Creative Tim & UPDIVISION" />
<meta property="og:type" content="article" />
<meta property="og:url" content="https://www.creative-tim.com/live/soft-ui-dashboard-laravel" />
<meta property="og:image" content="https://s3.amazonaws.com/creativetim_bucket/products/602/original/soft-ui-dashboard-laravel.jpg" />
<meta property="og:description" content="Learn with chat bot, English chat bot, English and Korea" />
<meta property="og:site_name" content="Creative Tim" />
