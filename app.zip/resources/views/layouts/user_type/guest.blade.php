@extends('layouts.app')

@section('guest')
    @yield('content')        
@endsection