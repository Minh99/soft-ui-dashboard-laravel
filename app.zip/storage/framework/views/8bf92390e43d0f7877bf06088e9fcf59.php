<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row mb-2" id="sentence-<?php echo e($item['id']); ?>">
    <label for="question" class="form-label font-weight-bold" style="font-size: 15px">
        <?php echo e($item['id']); ?>. <?php echo e($item['sentences']); ?>

    </label>
    <p>📍 <?php echo e(implode(', ', $item['suggest_words'])); ?> </p>
    <div class="form-row align-items-center">
        <div class="col-auto">
            <div class="input-group mb-2">
                <input type="text" 
                    class="form-control input-item" 
                    placeholder="Enter answer" 
                    id="<?php echo e($item['id']); ?>-input"
                    data-sentences="<?php echo e($item['sentences']); ?>"
                    data-uid="<?php echo e($item['id']); ?>"
                    data-suggest_words="<?php echo e(implode(', ', $item['suggest_words'])); ?>"
                >
            </div>
        </div>
    </div>
</div>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<button class="btn btn-primary mb-2 mt-2" id="submit">Submit</button>
<button class="btn btn-success mb-2 mt-2 d-none" id="submit-done">Mark as done</button>

<script>
    const data = <?php echo json_encode($data, 15, 512) ?>;
    const userTest2Id = <?php echo json_encode($userTest2Id, 15, 512) ?>;
    document.addEventListener('DOMContentLoaded', function() {
        $('#submit').click(function() {
            const texteds = $('input[type="text"]');
            var isContinue = true;
            for (let i = 0; i < texteds.length; i++) {
                const texted = texteds[i];
                const id = texted.id;
                const value = texted.value;
                if (value.trim() === '') {
                    isContinue = false;
                    $(texted).addClass('border-danger');
                }
            }

            if (isContinue) {
                var dataSubmit = [];
                var inputs = $('.input-item');
                inputs.each(function(index, item) {
                    const id = $(item).data('uid');
                    const sentences = $(item).data('sentences');
                    const suggest_words = $(item).data('suggest_words');
                    const user_answer = $(item).val();
                    dataSubmit.push({
                        id: id,
                        sentences: sentences,
                        suggest_words: suggest_words,
                        user_answer: user_answer
                    });
                });

                $.ajax({
                    url: "<?php echo e(route('test2-submit')); ?>",
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        user_test2_id: userTest2Id,
                        data: dataSubmit
                    },
                    beforeSend: function() {
                        $('.loader').show();
                    },
                    success: function(response) {
                        var $data = response?.data;
                        if (response.status === 200) {
                            var countCorrect = 0;
                            if ($data == null) {
                                alert('Please try again, something went wrong');
                                location.reload();
                            }
                            $data.forEach(function(value) {
                                let id = value.id;
                                let sentenceDom = $(`#sentence-${id}`);
                                let label = sentenceDom.find('label');
                                label.removeClass('text-danger');
                                label.find('span').remove();
                                sentenceDom.find('span').remove();
                                sentenceDom.find('br').remove();
                            });
                            $data.forEach(function(value) {
                                let sentences = value.sentences;
                                let example = value.example ?? [];
                                let result = value.result ?? false;
                                let explain = value.explain ?? '';
                                let how_to_fail = value.how_to_fail ?? '';
                                let id = value.id;
                                let sentenceDom = $(`#sentence-${id}`);
                                if (result) {
                                    countCorrect++;
                                    var label = sentenceDom.find('label');
                                    label.append(`<span> ✅ </span>`);
                                    example.forEach(function(it) {
                                        sentenceDom.append(`<span class="text-success text-sm"> 📝 ${it}</span><br>`)
                                    });
                                    sentenceDom.append(`<span class="text-success text-sm"> 🌟 ${explain}</span><br>`)
                                } else {
                                    var label = sentenceDom.find('label');
                                    label.addClass('text-danger');
                                    label.append(`<span> ❌ </span>`);
                                    sentenceDom.append(`<span class="text-danger text-sm"> 🚫 ${how_to_fail}</span><br>`)
                                    example.forEach(function(it) {
                                        sentenceDom.append(`<span class="text-danger text-sm"> 📝 ${it}</span><br>`)
                                    });
                                    sentenceDom.append(`<span class="text-danger text-sm"> 🌟 ${explain}</span><br>`)
                                }
                            });



                            if ($data.length - countCorrect <= 2) {
                                $('#submit-done').removeClass('d-none');
                                $('#submit-done').click(function() {
                                    location.href = "<?php echo e(route('mark-done-test-2')); ?>";
                                });
                            }
                        } else {
                            alert(response.message);
                            location.reload();
                        }
                    },
                    complete: function() {
                        $('.loader').hide();
                    },
                    error: function() {
                        $('.loader').hide();
                    }
                });
            }
        });

        $('.input-item').keyup(function() {
            $(this).removeClass('border-danger');
        });
    });
</script><?php /**PATH C:\laragon\www\soft-ui-dashboard-laravel\resources\views/components/type3.blade.php ENDPATH**/ ?>