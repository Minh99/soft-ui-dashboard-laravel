

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5>
                New User
            </h5>
        </div>
        <div class="card-body">
            <?php
                $route = route('user-management-store');
                if (!empty($user)) {
                    $route = route('user-management-store', ['id' => $user->id]);
                }
            ?>
            <form action="<?php echo e($route); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row mt-2">
                    <div class="fom-group col-md-6">
                        <label for="name">Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php if(!empty($user)): ?><?php echo e($user->name); ?><?php else: ?><?php echo e(old('name')); ?><?php endif; ?>">
						<?php if($errors->has('name')): ?>
                            <span class="text-danger text-xs">
                                <?php echo e($errors->first('name')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="fom-group col-md-6">
                        <label for="name">Email <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="email" name="email" <?php if(!empty($user)): ?> disabled <?php endif; ?> value="<?php if(!empty($user)): ?><?php echo e($user->email); ?><?php else: ?><?php echo e(old('email')); ?><?php endif; ?>">
                        <?php if($errors->has('email')): ?>
                            <span class="text-danger text-xs">
                                <?php echo e($errors->first('email')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="fom-group col-md-6">
                        <label for="name"> <?php echo e(!empty($user) ? 'Edit ' : ''); ?>Password <span class="text-danger"></span></label>
                        <input type="text" class="form-control" id="password" name="password" value="<?php echo e(old('password')); ?>">
						<?php if($errors->has('password')): ?>
                            <span class="text-danger text-xs">
                                <?php echo e($errors->first('password')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="fom-group col-md-6">
                        <label for="name">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php if(!empty($user)): ?><?php echo e($user->phone); ?><?php else: ?><?php echo e(old('phone')); ?><?php endif; ?>">
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="fom-group col-md-6">
                        <button class="btn btn-primary col-md-3" type="submit">
                            Save
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\soft-ui-dashboard-laravel\resources\views/profile.blade.php ENDPATH**/ ?>