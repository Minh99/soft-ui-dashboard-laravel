<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form class="mb-4">
        <p class="form-label font-weight-bold text-lg"> Paragraph <?php echo e($key + 1); ?> </p>
        <label class="form-label font-weight-bold" style="font-size: 15px">
            🅿️ <?php echo e($item['graph']); ?>

        </label>
        <label class="form-label font-weight-bold" style="font-size: 15px;">
            <?php
                shuffle($item['options']);
            ?>
            🔷 (<i> <?php echo e(implode(', ', $item['options'])); ?> </i>)
        </label>
        <?php $__currentLoopData = $item['correct_answer']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-row align-items-center">
                <div class="col-auto">
                    <div class="input-group mb-2">
                        <div class="input-group-prepend input-group-text" id="pos-<?php echo e($key); ?>-<?php echo e($k); ?>">
                            Postion <?php echo e($k + 1); ?>

                        </div>
                        <input type="text" class="form-control" placeholder="Enter answer" id="<?php echo e($key); ?>-<?php echo e($k); ?>">
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<button type="button" class="btn btn-primary mb-2 mt-2" id="submit">Submit</button>
<button type="button" class="btn btn-success mb-2 mt-2 d-none" id="submit-done">Mark as done</button>

<script>
    const data = <?php echo json_encode($data, 15, 512) ?>;
    const userTest2Id = <?php echo json_encode($userTest2Id, 15, 512) ?>;
    console.log(data);
    console.log(userTest2Id);
    document.addEventListener('DOMContentLoaded', function() {
        $('#submit').click(function() {
            const texteds = $('input[type="text"]');
            for (let i = 0; i < texteds.length; i++) {
                const texted = texteds[i];
                const id = texted.id;
                const value = texted.value;
               
                const [pos, index] = id.split('-');

                $(`#pos-${pos}-${index}`).removeClass('text-success');
                $(`#pos-${pos}-${index}`).removeClass('text-danger');
                $(`#pos-${pos}-${index}`).text('Postion ' + (parseInt(index) + 1));
            }

            var countPassed = 0;
            for (let i = 0; i < texteds.length; i++) {
                const texted = texteds[i];
                const id = texted.id;
                const value = texted.value;
               
                const [pos, index] = id.split('-');
                const correctAnswer = data[pos].correct_answer[index];
                if (value.trim().toLowerCase() === correctAnswer.trim().toLowerCase()) {
                    countPassed++;
                    $(`#pos-${pos}-${index}`).addClass('text-success');
                    $(`#pos-${pos}-${index}`).append(`<span> ✅ </span>`);
                } else {
                    $(`#pos-${pos}-${index}`).addClass('text-danger');
                    $(`#pos-${pos}-${index}`).append(`<span> ❌ </span>`);
                }
            }

            if (countPassed == texteds.length) {
                $('#submit').addClass('d-none');
                $('#submit-done').removeClass('d-none');
                $('#submit-done').click(function() {
                    location.href = "<?php echo e(route('mark-done-test-2')); ?>";
                });
            }
        });
    });
</script><?php /**PATH C:\laragon\www\soft-ui-dashboard-laravel\resources\views/components/type2.blade.php ENDPATH**/ ?>