

<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Quiz</h4>
                        <span>
                            <?php if($type == 1): ?>
                                Fill in the blank with the correct word
                            <?php elseif($type == 2): ?>
                                Fill in the blank with the correct word
                            <?php elseif($type == 3): ?>
                                Translate the following word
                            <?php elseif($type == 4): ?>
                                Make a sentence with the following word
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <?php if($type == 1): ?>
                            <?php echo $__env->make('components.type1', ['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($type == 2): ?>
                            <?php echo $__env->make('components.type2', ['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($type == 3): ?>
                            <?php echo $__env->make('components.type3', ['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($type == 4): ?>
                            <?php echo $__env->make('components.type4', ['data' => $data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\soft-ui-dashboard-laravel\resources\views/test2-type1.blade.php ENDPATH**/ ?>