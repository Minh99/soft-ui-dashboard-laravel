

<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Quiz</h4>
                        <span><?php echo e(count($quizTypeRandom)); ?>  questions</span>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('quiz-for-submit')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <?php $__currentLoopData = $quizTypeRandom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($question['type'] == 'radio'): ?>
                                    <label for="question" class="form-check-label font-weight-bold"><?php echo e($key + 1); ?>. Do you know "<font style="color: rgb(85, 18, 18)"><?php echo e($question['en']); ?></font>" mean? </label>
                                    <div class="form-check">
                                        <div class="form-check form-check-block">
                                            <input class="form-check-input" type="radio" name="<?php echo e($question['id']); ?>-en" id="<?php echo e($question['id']); ?>-answer1" value="1">
                                            <label class="form-check-label" for="<?php echo e($question['id']); ?>-answer1">Yes</label>
                                        </div>
                                        <div class="form-check form-check-block">
                                            <input class="form-check-input" type="radio" name="<?php echo e($question['id']); ?>-en" id="<?php echo e($question['id']); ?>-answer2" value="2">
                                            <label class="form-check-label" for="<?php echo e($question['id']); ?>-answer2">No</label>
                                        </div>
                                        <div class="form-check form-check-block">
                                            <input class="form-check-input" type="radio" name="<?php echo e($question['id']); ?>-en" id="<?php echo e($question['id']); ?>-answer3" value="3">
                                            <label class="form-check-label" for="<?php echo e($question['id']); ?>-answer3">Not sure</label>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <label for="<?php echo e($question['id']); ?>-answer1" class="form-check-label font-weight-bold"><?php echo e($key + 1); ?>. What is the meaning of "<font style="color: rgb(85, 18, 18)"><?php echo e($question['ko']); ?></font>"? </label>
                                    <div class="form-group">
                                        <input type="text" name="<?php echo e($question['id']); ?>-ko" class="form-control mb-2 mx-2" id="<?php echo e($question['id']); ?>-answer1" placeholder="Enter answer">
                                    </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                           
                            <button type="submit" class="btn btn-primary float-right">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\soft-ui-dashboard-laravel\resources\views/quiz-for.blade.php ENDPATH**/ ?>