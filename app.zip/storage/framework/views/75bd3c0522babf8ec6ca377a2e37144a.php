

<?php $__env->startSection('content'); ?>
    <div class="main-content position-relative bg-gray-100 max-height-vh-100 h-100">
        <div class="container-fluid py-4">
            <div class="row">
                <div class="col-12 mt-4">
                    <div class="card mb-4">
                        <div class="card-header pb-0 p-3">
                            <h6 class="mb-1">Topics</h6>
                            <p class="text-sm">Choose your desired topic and let's get started</p>
                        </div>
                        
                        <div class="card-body p-3">
                            <div class="row">
                                <style>
                                    .topic-image:hover {
                                        transform: scale(1.1);
                                        transition: transform 1.5s;
                                    }
                                    .topic-image:hover::after {
                                        content: "";
                                        position: absolute;
                                        top: 0;
                                        left: 0;
                                        right: 0;
                                        bottom: 0;
                                        background-color: rgba(46, 45, 46, 0.5);
                                        border-radius: 10px;
                                    }
                                </style>
                                <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xl-3 col-md-4 col-sm-6 mb-4">
                                    <div class="card card-blog pb-2 px-2 rounded">
                                        <div class="position-relative topic-image"
                                            style="background-image: url('<?php echo e($topic->image); ?>'); background-size: cover; background-position: center; height: 150px; border-radius: 10px; overflow: hidden;">
                                        </div>
                                        <div class="card-body px-1 pb-0">
                                            <a href="javascript:;">
                                                <p class="text-gradient text-dark mb-2 text-sm"><?php echo e($topic->name); ?></p>
                                            </a>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <a data-topic-id="<?php echo e($topic->id); ?>"  class="btn btn-outline-primary btn-sm mb-0 btn-go-to-topic-detail font-weight-bold">
                                                    Start
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user_type.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\soft-ui-dashboard-laravel\resources\views/pages/topics/index.blade.php ENDPATH**/ ?>