<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserKnownController extends Controller
{
    //
}
